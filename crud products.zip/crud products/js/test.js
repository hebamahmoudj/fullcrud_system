

console.log(localStorage.getItem('myProducts'));